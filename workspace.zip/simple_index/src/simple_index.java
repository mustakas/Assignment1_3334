import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapred.Counters.Counter;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.util.StringUtils;
import org.apache.log4j.Logger;

public class simple_index extends Configured implements Tool {
	private static final Logger LOG = Logger.getLogger(simple_index.class);

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new simple_index(), args);
		System.exit(res);
	}

	public int run(String[] args) throws Exception {

		Job job = Job.getInstance(getConf(), "wordcount");
		job.setJarByClass(this.getClass());
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setMapperClass(Map.class);
		job.setReducerClass(Reduce.class);
		MultipleOutputs.addNamedOutput(job, "text", TextOutputFormat.class,LongWritable.class, Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		job.waitForCompletion(true);
		return 1;
	}

	public static class Map extends Mapper<LongWritable, Text, Text, Text> {
		Scanner sc;
		List<String> wordList = new ArrayList<String>();
		private boolean caseSensitive = false;
		private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*[^a-zA-Z]\\s*");

		protected void setup(Mapper.Context context) throws IOException,InterruptedException {
			Configuration config = context.getConfiguration();
			this.caseSensitive = config.getBoolean("wordcount.case.sensitive",false);
			sc = new Scanner(new File("Stopwords.csv"));
			for (int i = 0; sc.hasNext() != false; i++) {
				wordList.add(sc.next());
			}
		}

		public void map(LongWritable offset, Text lineText, Context context) throws IOException, InterruptedException {
			String line = lineText.toString();
			String fileName = ((FileSplit) context.getInputSplit()).getPath().getName();
			if (!caseSensitive) {
				line = line.toLowerCase();
			}
			Text currentWord = new Text();
			for (String word : WORD_BOUNDARY.split(line)) {
				if (word.isEmpty()) {
					continue;
				}
				if (wordList.contains(word)) {
					continue;
				}
				currentWord = new Text(word);
				context.write(currentWord, new Text(fileName));
			}
		}
	}


	public static class Reduce extends Reducer<Text, Text, Text, Text> {

		private static int cntr = 0;
		private MultipleOutputs mos;

		public void setup(Context context) {
			mos = new MultipleOutputs(context);
		}

		@Override
		public void reduce(Text word, Iterable<Text> counts, Context context) throws IOException, InterruptedException {
			String sum = new String();
			ArrayList<String> df = new ArrayList<String>();
			for (Text count : counts) {
				df.add(count.toString());
			}
			HashSet<String> uniquevals = new HashSet<>(df);
			for (String value : uniquevals) {
				sum = sum + "   ";
				sum = sum + value;
			}
			String out = new String();
			out = word.toString();
			cntr++;
			out = "#" + cntr + "   " + out;
			context.write(new Text(out), new Text(sum));
		}

		public void cleanup(Context context) throws IOException,InterruptedException {
			mos.write("text", new Text("My_Counter: "),new Text(Integer.toString(cntr)));
			mos.close();
		}

	}
}
