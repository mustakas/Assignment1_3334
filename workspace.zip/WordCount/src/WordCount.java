import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class WordCount extends Configured implements Tool {
	private static final Logger LOG = Logger.getLogger(WordCount.class);
	private static HashMap<String, Integer> top=new HashMap<String, Integer>();
	
	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new WordCount(), args);
		 System.exit(res);
	}

	public int run(String[] args) throws Exception {
		Job job = Job.getInstance(getConf(), "wordcount");
		job.setJarByClass(this.getClass());
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setMapperClass(Map.class);
		job.setCombinerClass(Reduce.class);
		job.setReducerClass(Reduce.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		int i = job.waitForCompletion(true) ? 0 : 1;
		if (i == 0) {
			Job job1 = Job.getInstance(getConf(), "wordcount");
			job1.setJarByClass(this.getClass());
			FileInputFormat.addInputPath(job1, new Path(args[1]));
			FileOutputFormat.setOutputPath(job1, new Path(args[2]));
			job1.setMapperClass(Map1.class);
			job1.setSortComparatorClass(KComparator.class);
			job1.setReducerClass(Reduce1.class);
			job1.setMapOutputKeyClass(IntWritable.class);
			job1.setMapOutputValueClass(Text.class);
			job1.setOutputKeyClass(Text.class);
			job1.setOutputValueClass(IntWritable.class);
			i = job1.waitForCompletion(true) ? 0 : 1;
			if (i == 0) {
				Job job2 = Job.getInstance(getConf(), "wordcount");
				job2.setJarByClass(this.getClass());
				FileInputFormat.addInputPath(job2, new Path(args[2]));
				FileOutputFormat.setOutputPath(job2, new Path(args[3]));
				job2.setMapperClass(Map2.class);
				job2.setSortComparatorClass(KComparator.class);
				job2.setReducerClass(Reduce2.class);
				job2.setNumReduceTasks(1);
				job2.setMapOutputKeyClass(IntWritable.class);
				job2.setMapOutputValueClass(Text.class);
				job2.setOutputKeyClass(Text.class);
				job2.setOutputValueClass(IntWritable.class);
				i = job2.waitForCompletion(true) ? 0 : 1;
			}
			return i;
		} else {
			return 1;
		}
	}
	
	
	//-----
	//First Job
	//-----

	public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
		private final static IntWritable one = new IntWritable(1);
		private Text word = new Text();
		private boolean caseSensitive = false;
		private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*[^a-zA-Z]\\s*");
		

		protected void setup(Mapper.Context context) throws IOException,InterruptedException {
			Configuration config = context.getConfiguration();
			this.caseSensitive = config.getBoolean("wordcount.case.sensitive",false);
		}

		public void map(LongWritable offset, Text lineText, Context context) throws IOException, InterruptedException {
			String line = lineText.toString();
			if (!caseSensitive) {
				line = line.toLowerCase();
			}
			Text currentWord = new Text();
			for (String word : WORD_BOUNDARY.split(line)) {
				if (word.isEmpty()) {
					continue;
				}
				currentWord = new Text(word);
				context.write(currentWord, one);
			}
		}
	}

	public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
		@Override
		public void reduce(Text word, Iterable<IntWritable> counts,
				Context context) throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable count : counts) {
				sum += count.get();
			}
			context.write(word, new IntWritable(sum));
		}
	}
	
	//-----
	//Second Job
	//-----
	
	public static class KComparator extends WritableComparator {
		protected KComparator() {
			super(IntWritable.class, true);
		}
		@SuppressWarnings("rawtypes")
		@Override
		public int compare(WritableComparable no1, WritableComparable no2) {
			IntWritable out1 = (IntWritable) no1;
			IntWritable out2 = (IntWritable) no2;
			return -1 * out1.compareTo(out2);
		}
	}
	
	
	
	public static class Map1 extends Mapper<LongWritable, Text, IntWritable, Text> {
		private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*[^a-zA-Z0-9]\\s*");
		
		
		protected void setup(Mapper.Context context) throws IOException,InterruptedException {
				Configuration config = context.getConfiguration();
		}

		public void map(LongWritable offset, Text lineText, Context context) throws IOException, InterruptedException {
			String line = lineText.toString();
			Text currentWord = new Text();
			IntWritable freq;
			for (String word : WORD_BOUNDARY.split(line)) {
				if (word.isEmpty()) {
					continue;
				}
				if (currentWord.getLength() == 0) {
					currentWord = new Text(word);
				} else {
					freq = new IntWritable(Integer.parseInt((word.toString())));
					if (freq.get() > 4000) {
						context.write(freq, currentWord);
					} else {
						currentWord = new Text();
						freq = new IntWritable();
					}
				}
			}
		}
	}
	


	public static class Reduce1 extends Reducer<IntWritable, Text, Text, IntWritable> {
		@Override
		public void reduce(IntWritable freq, Iterable<Text> words,Context context) throws IOException, InterruptedException {
			for (Text count : words) {
				context.write(count, freq);
			}
		}
	}

	//-----
	//Third Job
	//-----
	
	public static class Map2 extends Mapper<LongWritable, Text, IntWritable, Text> {
		private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*[^a-zA-Z0-9]\\s*");
		
		
		protected void setup(Mapper.Context context) throws IOException,InterruptedException {
				Configuration config = context.getConfiguration();
		}

		public void map(LongWritable offset, Text lineText, Context context) throws IOException, InterruptedException {
			String line = lineText.toString();
			Text currentWord = new Text();
			IntWritable freq;
			for (String word : WORD_BOUNDARY.split(line)) {
				if (word.isEmpty()) {
					continue;
				}
				if (currentWord.getLength() == 0) {
					currentWord = new Text(word);
				} else {
					freq = new IntWritable(Integer.parseInt((word.toString())));
					if (freq.get() > 4000) {
						context.write(freq, currentWord);
						top.put(currentWord.toString(),freq.get());
					} else {
						currentWord = new Text();
						freq = new IntWritable();
					}
				}
			}
		}
	}
	
	public static class Reduce2 extends Reducer<IntWritable, Text, Text, IntWritable> {
		static int cnt=0;
		@Override
		public void reduce(IntWritable freq, Iterable<Text> words,Context context) throws IOException, InterruptedException {
			HashMap<String, Integer> sorted = sortByComparator(top);
			for (Entry<String, Integer> entry : sorted.entrySet()){
				if(cnt<10){
					Text o1=new Text(entry.getKey());
					IntWritable o2=new IntWritable(entry.getValue());
					context.write(o1,o2);
					cnt++;
				}
			}
		}
	}
	
	
    private static HashMap<String, Integer> sortByComparator(HashMap<String, Integer> unsort){

        List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(unsort.entrySet());
        Collections.sort(list, new Comparator<Entry<String, Integer>>(){
            public int compare(Entry<String, Integer> elem1,Entry<String, Integer> elem2){
                    return elem2.getValue().compareTo(elem1.getValue());
            }
        });
        HashMap<String, Integer> sorted = new LinkedHashMap<String, Integer>();
        for (Entry<String, Integer> entry : list){
        	sorted.put(entry.getKey(), entry.getValue());
        }
        return sorted;
    }
}
